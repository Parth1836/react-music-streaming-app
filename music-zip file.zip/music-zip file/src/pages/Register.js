function Register() {
    return (
        <h1>Register</h1>
    )
}

export default Register;