// import Jwt  from "jsonwebtoken";
const jwtKey = "music-stream";

export const verifyUser = (userCredentials)=> {
    // const result = Jwt.sign({userCredentials}, jwtKey);
    // console.log("result", result);
    return true;
}