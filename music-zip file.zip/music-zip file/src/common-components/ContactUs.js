import Header from "./Header";

function ContactUs () {
    return (
        <>
        <Header />
        <h2>Contact Us</h2>
        </>
    )
}

export default ContactUs;